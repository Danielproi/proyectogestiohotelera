preguntas = (
    ('Primer nombre de tu mamá', 'Primer nombre de tu mamá'),
    ('Mes de nacimiento', 'Mes de nacimiento'),
    ('Color Favorito', 'Color Favorito'),
    ('Deporte Favorito', 'Deporte Favorito'),
    ('Lugar de Nacimiento', 'Lugar de Nacimiento'),
)