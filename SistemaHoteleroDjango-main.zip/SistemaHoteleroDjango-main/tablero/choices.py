estados = (
    ('Disponible', 'Disponible'),
    ('Ocupado', 'Ocupado'),
    ('Mantenimiento', 'Mantenimiento'),
    ('Reservada', 'Reservada')
)

tipos = (
    ('Doble Individual', 'Doble Individual'),
    ('Triple Individual', 'Triple Individual'),
    ('Matrimonial + Individual', 'Matrimonial + Individual'),
    ('Doble Matrimonial', 'Doble Matrimonial'),
    ('Matrimonial Queen', 'Matrimonial Queen'),
    ('Matrimonial King', 'Matrimonial King'),
    ('Matrimonial', 'Matrimonial')
)