from django.contrib import admin
from tablero.models import Habitacion

# Register your models here.
admin.site.register(Habitacion)
