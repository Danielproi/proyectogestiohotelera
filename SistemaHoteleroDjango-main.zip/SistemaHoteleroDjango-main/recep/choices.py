metodoPago = (
    ('Divisas', 'Divisas'),
    ('Pago Movil', 'Pago Movil'),
    ('Transferencia', 'Transferencia'),
    ('Binance', 'Binance'),
    ('Zinli', 'Zinli'),
    ('Paypal', 'Paypal'),
    ('Punto de Venta', 'Punto de Venta'),
    ('Tarjeta de Credito', 'Tarjeta de Credito'),
    ('Biopago', 'Biopago'),
)

monedas = (
    ('Dolares', 'Dolares'),
    ('Bolivares', 'Bolivares'),
    ('Pesos CO', 'Pesos CO'),
    ('USDT', 'USDT'),
    ('BTC', 'BTC')
)

