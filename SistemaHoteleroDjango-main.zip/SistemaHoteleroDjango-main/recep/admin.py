from django.contrib import admin
from recep.models import  *

# Register your models here.
admin.site.register(Reserva)
admin.site.register(Cliente)
